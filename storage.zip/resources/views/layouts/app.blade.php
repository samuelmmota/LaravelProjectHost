<html>
 
 <body>

@include('includes.header')


   @yield('title')

   @yield('content')


@include('includes.footer')



</body>



</html>